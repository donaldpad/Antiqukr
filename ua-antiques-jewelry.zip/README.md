# Ukrainian Antiques & Jewelry

This is a static website showcasing 40 Ukrainian antique and jewelry items using placeholder images and descriptions.

## How to Deploy with GitHub Pages

1. Create a GitHub repository
2. Upload `index.html` to the root of the repository
3. Go to Repository → Settings → Pages
4. Under "Source", select `main` branch and `/ (root)` folder
5. GitHub will provide a live HTTPS link to your site
